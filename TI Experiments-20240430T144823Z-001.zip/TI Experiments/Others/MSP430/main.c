/***********************************
 *
 *
 *                              **************************
 *                              *   LED Toggle in P1.0  *
 *                              **************************
 *
 *
 */

#include<msp430g2553.h>

void main(void)
{
    WDTCTL  = WDTPW + WDTHOLD;               // Stop WDT
    BCSCTL1 = CALBC1_1MHZ;                   // Set DCO
    DCOCTL  = CALDCO_1MHZ;                   //enable digital control oscillator
    P1DIR   = 0x01;                          // Set P1.0 direction register as output
    P1OUT   = 0x00;                          // Clear all the port bits for initial condition

    while(1)
    {
        P1OUT ^= 0x01;                       // X-OR 0x01 with P1OUT register.
        __delay_cycles(3000000);             //  delay for 1 second

    }
}

